'use strict';

const LaunchRequestHandler = function () {
    this.emit('HelloWorldIntent');
};

module.exports = LaunchRequestHandler;